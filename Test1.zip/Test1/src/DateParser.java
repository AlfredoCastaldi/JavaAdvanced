import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

public class DateParser{
    private OffsetDateTime date = OffsetDateTime.now();
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("eeee dd MMMM yyyy");
    private String stringDate = this.date.format(formatter);


    public DateParser(String data){
        this.date = OffsetDateTime.parse(data);
    }
    public void addDays(int days){this.date.plusDays(days);}
    public OffsetDateTime getDate() {
        return date;
    }
    public String getStringDate() {return stringDate;}
    public boolean isAfter(OffsetDateTime date){return this.isAfter(date);}
    public boolean isBefore(OffsetDateTime date){return this.date.isBefore(date);}
    public boolean isEqual(OffsetDateTime date){
        return this.isEqual(date);
    }
}