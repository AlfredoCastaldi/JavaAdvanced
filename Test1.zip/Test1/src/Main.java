import java.text.Format;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.FormatStyle;
import java.util.Locale;


public class Main {
    public static void main(String[] args) {

        DateParser data1 = new DateParser("2023-01-02T13:00:00Z");
        System.out.println(data1.getStringDate());
    }
}

