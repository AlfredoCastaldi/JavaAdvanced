import com.sun.jdi.connect.Connector;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Assert.*;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

public class DateParserTest {

    @Test
    public void dateShouldBe10AfterSevenDays(){
        OffsetDateTime newDate = OffsetDateTime.parse("2023-01-02T13:00:00Z");
        OffsetDateTime newDate2 = newDate.plusDays(7);
        Assert.assertEquals("mi aspetto che il giorno sia il 10 dopo 7 giorni dal giorno " + newDate.getDayOfMonth(),10, newDate2.getDayOfMonth());
    }

    @Test
    public void dateShouldBeDateFormat(){

    }
    @Test
    public void date23ShouldBeBeforeDate24(){

    }
    @Test
    public void date25ShouldBeAfterDate24(){

    }

}
